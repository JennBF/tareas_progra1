#include "configuracion.h"

Configuracion::Configuracion()
{
    //ctor
}

Configuracion::~Configuracion()
{
    //dtor
}
